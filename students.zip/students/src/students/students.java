/*******************************************************************************
* Created by: Matthew Brean
* Created on: 2016-09-26
* Created for: ICS4U
* Daily Assignment: Unit #1-11
* Asks for student information, saves in array, says back.
*******************************************************************************/

package students;
import java.util.Scanner;

	//abstract data type
	class A {
	
		String firstn;
		String lastn;
		String initial;
		String grade;
	
	}

public class students {

	public static void main(String[] args) {
	
        String[] anArray;
        anArray = new String[4];
        
    	@SuppressWarnings("resource")
		Scanner SCAN= new Scanner(System.in);
    	
    	System.out.println("First name: ");
    	String firstn = SCAN.nextLine();
    	anArray[0]=firstn;
    	System.out.println("Last name: ");
    	String lastn = SCAN.nextLine();
    	anArray[1]=lastn;
    	System.out.println("Initial: ");
    	String initial = SCAN.nextLine();
    	anArray[2]=initial;
    	System.out.println("Grade: ");
    	String grade = SCAN.nextLine();
    	anArray[3]=grade;
    	
    	System.out.println(firstn+" "+initial+" "+lastn+" is in grade "+grade+".");
    	
	}

}


